package com.cg.movie.services;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Music;
import com.cg.movie.daoservices.MovieDAO;
import com.cg.movie.daoservices.MusicDAO;
import com.cg.movie.exceptions.MovieDetailsNotFoundException;
@Component("movieServices")
public class MovieServicesImpl implements MovieServices{
	@Autowired
	private MovieDAO movieDAO;
	@Autowired
	private MusicDAO musicDAO;
	@Override
	public Movie acceptMovieDetails(Movie movie) {
		movie=movieDAO.save(movie);
		musicDAO.save(new Music(movie));
		return movie;
	}
	@Override
	public Movie getMovieDetails(int movieId) throws MovieDetailsNotFoundException {
		return movieDAO.findById(movieId).orElseThrow(()->new MovieDetailsNotFoundException("Movie Details Not Found Of Movie Id"+movieId));
	}
	@Override
	public List<Movie> getAllMovieDetails() {
		return movieDAO.findAll();
	}
	@Override
	public boolean removeMovieDetails(int movieId) throws MovieDetailsNotFoundException {
		movieDAO.delete(getMovieDetails(movieId));
		return true;
	}
	@Override
	public List<Music> getAllMusicDetails(int movieId) {
		List<Music> mov=musicDAO.findAll();
		return mov;
	}
	@Override
	public Music acceptMusicDetails(Music music) {
		// TODO Auto-generated method stub
		return null;
	}
}
