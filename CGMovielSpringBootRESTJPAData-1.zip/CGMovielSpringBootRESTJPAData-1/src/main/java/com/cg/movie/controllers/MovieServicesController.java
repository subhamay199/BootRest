package com.cg.movie.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.movie.beans.Movie;
import com.cg.movie.exceptions.MovieDetailsNotFoundException;
import com.cg.movie.services.MovieServices;

@Controller
public class MovieServicesController {
	@Autowired
	MovieServices movieServices;
@RequestMapping(value={"/sayHello"},method=RequestMethod.GET)
public ResponseEntity<String> sayHello(){
	return new ResponseEntity<String>("Hello",HttpStatus.OK);
}
@RequestMapping(value={"/getMovieDetails/{movieId}"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
headers="Accept=application/json")
public ResponseEntity<Movie> getAssociateDetailsPathParam(@PathVariable(value="movieId")int movieId) throws MovieDetailsNotFoundException{
	Movie movie=movieServices.getMovieDetails(movieId);
	return new ResponseEntity<Movie>(movie,HttpStatus.OK);
}
@RequestMapping(value={"/getAllMovieDetails"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
headers="Accept=application/json")
public ResponseEntity<List<Movie>> getAssociateDetailsPathParam() {
		return new ResponseEntity<List<Movie>>(movieServices.getAllMovieDetails(),HttpStatus.OK);
}
@RequestMapping(value={"/acceptAssociateDetails"},method=RequestMethod.POST,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
public ResponseEntity<String> acceptAssociateDetails(@ModelAttribute Movie movie) throws MovieDetailsNotFoundException{
	movie=movieServices.acceptMovieDetails(movie);
	return new ResponseEntity<>("Associate details successfully added associateId"+movie.getMovieId(),HttpStatus.OK);
}
@RequestMapping(value={"/removeMovieDetails"},method=RequestMethod.DELETE,produces=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
public ResponseEntity<String> removeMovieDetails(@RequestParam int movieId) throws MovieDetailsNotFoundException{
	movieServices.removeMovieDetails(movieId);
	return new ResponseEntity<>("Movie details successfully added Movie Id",HttpStatus.OK);
}

}
