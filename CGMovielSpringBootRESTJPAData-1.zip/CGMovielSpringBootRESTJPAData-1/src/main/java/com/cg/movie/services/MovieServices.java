package com.cg.movie.services;

import java.util.List;

import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Music;
import com.cg.movie.exceptions.MovieDetailsNotFoundException;

public interface MovieServices {
Movie acceptMovieDetails(Movie movie);
Music acceptMusicDetails(Music music);
Movie getMovieDetails(int movieId) throws MovieDetailsNotFoundException;
List<Movie> getAllMovieDetails();
List<Music> getAllMusicDetails(int movieId);
boolean removeMovieDetails(int movieId) throws MovieDetailsNotFoundException;
}
