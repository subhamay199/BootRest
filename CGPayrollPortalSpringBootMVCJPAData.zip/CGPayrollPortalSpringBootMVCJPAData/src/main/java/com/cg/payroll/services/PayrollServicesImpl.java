package com.cg.payroll.services;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
@Component("payrollServices")
public class PayrollServicesImpl  implements PayrollServices{
	@Autowired
	private AssociateDAO associateDao;
	@Override
	public Associate acceptAssociateDetails(Associate associate) {
		//Associate associate =new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId,new Salary(basicSalary, epf, companyPf),new BankDetails(accountNumber, bankName, ifscCode));
		associate=associateDao.save(associate);
		return associate;
	}
	@Override
	public double calculateAnnualGrossSalary(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate=associateDao.findById(associateId).orElseThrow(()-> new AssociateDetailsNotFoundException("AssociateDetails not found for the Associate ID"+associateId));

		return ((associate.getSalary().getBasicSalary())+(0.3*(associate.getSalary().getBasicSalary())*2)+
				(0.25*(associate.getSalary().getBasicSalary()))+(0.2*(associate.getSalary().getBasicSalary()))+
				associate.getSalary().getCompanyPf()+associate.getSalary().getEpf())*12;
	}
	@Override
	public double calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate=associateDao.findById(associateId).orElseThrow(()-> new AssociateDetailsNotFoundException("AssociateDetails not found for the Associate ID"+associateId));
		return calculateAnnualGrossSalary(associateId)-associate.getSalary().getCompanyPf()-associate.getSalary().getEpf();
	}
	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException {
		return associateDao.findById(associateId).orElseThrow(()-> new AssociateDetailsNotFoundException("AssociateDetails not found for the Associate ID"+associateId));
		 
	}
	@Override
	public List<Associate> getAllAssociateDetails() {
		return associateDao.findAll();
	}
	@Override
	public double taxCalculator(int associateId) {
		Associate associate=associateDao.findById(associateId).orElseThrow(()-> new AssociateDetailsNotFoundException("AssociateDetails not found for the Associate ID"+associateId));
		double grossSal=calculateAnnualGrossSalary(associateId);
		if(grossSal<=250000)
			return 0;
		else if(grossSal>250000&& grossSal<=500000)
		{
			grossSal-=250000;
			return grossSal/10;
		}
		else if(grossSal>500000&& grossSal<=1000000)
		{
			grossSal-=500000;
			return grossSal/5+25000;
		}
		else 
		{
			grossSal-=1000000;
			return (grossSal*3/10)+50000+25000;
		}

	}
}